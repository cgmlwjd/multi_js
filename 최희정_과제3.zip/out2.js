function 여행하다(){
    document.write('좋은 여행 되세요');
}
function 쉬다(){
    document.write('푹 쉬세요.');
}